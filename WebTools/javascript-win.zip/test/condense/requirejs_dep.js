define(['./requirejs_const'], function(requirejs_const) {
  return {a: requirejs_const};
});
