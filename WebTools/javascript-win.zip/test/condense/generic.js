function x(y) { return y.bar; }
