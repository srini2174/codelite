export {a, c as b} from "./blah"
