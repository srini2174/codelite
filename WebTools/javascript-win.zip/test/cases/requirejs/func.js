define(function(require, exports, module){
  function aFunction() { return false; }
  return aFunction;
});
