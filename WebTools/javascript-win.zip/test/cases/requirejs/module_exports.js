define(["module"], function(module) {
  module.exports = {one: 1, two: 2};
});
