define(["exports"], function(exports) {
  exports.someprop = "a string";
});
