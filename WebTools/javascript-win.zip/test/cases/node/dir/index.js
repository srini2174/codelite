exports.foo = "hey";
exports.rel = require("./lib/relative");
